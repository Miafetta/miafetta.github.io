import http.client
import json
import logging
import os
import re
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from urllib.parse import urlsplit


UPSTREAM_TIMEOUT = 8
MAX_UPSTREAM_BYTES = 4 * 1024 * 1024
BEARER = re.compile(r"Bearer +[A-Za-z0-9._~+/-]+=*", re.IGNORECASE | re.ASCII)
MODEL_FIELDS = {
    "display_name": str,
    "supported_reasoning_levels": list,
    "shell_type": str,
    "visibility": str,
    "supported_in_api": bool,
    "priority": int,
    "support_verbosity": bool,
    "truncation_policy": dict,
    "experimental_supported_tools": list,
}


class CatalogError(Exception):
    def __init__(self, status, code):
        super().__init__(code)
        self.status = status
        self.code = code


def origin(name, default):
    url = urlsplit(os.environ.get(name, default))
    if (
        url.scheme != "http" or not url.hostname or url.username is not None
        or url.path not in ("", "/") or url.query or url.fragment
    ):
        raise ValueError(f"{name} must be an internal HTTP origin")
    return url.hostname, url.port or 80


def reject_constant(_):
    raise ValueError("invalid JSON constant")


def fetch(upstream, address, path, authorization):
    connection = http.client.HTTPConnection(*address, timeout=UPSTREAM_TIMEOUT)
    try:
        # Direct HTTP requests never follow redirects or use environment proxies.
        connection.request("GET", path, headers={
            "Authorization": authorization,
            "Accept": "application/json",
        })
        with connection.getresponse() as response:
            if upstream == "new_api" and response.status in (401, 403):
                raise CatalogError(response.status, "token_rejected")
            if response.status != 200:
                raise CatalogError(502, f"{upstream}_unavailable")
            length = response.length
            if length is not None and length > MAX_UPSTREAM_BYTES:
                raise CatalogError(502, f"{upstream}_response_too_large")
            body = response.read(MAX_UPSTREAM_BYTES + 1)
            if len(body) > MAX_UPSTREAM_BYTES:
                raise CatalogError(502, f"{upstream}_response_too_large")
            if length is not None and len(body) != length:
                raise CatalogError(502, f"{upstream}_invalid_response")
        return json.loads(body, parse_constant=reject_constant)
    except TimeoutError:
        raise CatalogError(504, f"{upstream}_timeout") from None
    except (OSError, http.client.HTTPException):
        raise CatalogError(502, f"{upstream}_unavailable") from None
    except (ValueError, RecursionError):
        raise CatalogError(502, f"{upstream}_invalid_response") from None
    finally:
        connection.close()


def indexed_rows(document, array_field, id_field, upstream):
    rows = document.get(array_field) if isinstance(document, dict) else None
    if not isinstance(rows, list):
        raise CatalogError(502, f"{upstream}_invalid_response")
    indexed = {}
    for row in rows:
        key = row.get(id_field) if isinstance(row, dict) else None
        if not isinstance(key, str) or not key.strip() or key in indexed:
            raise CatalogError(502, f"{upstream}_invalid_response")
        indexed[key] = row
    return indexed


class CatalogServer(ThreadingHTTPServer):
    def __init__(self, address, new_api, cpr, cpr_key):
        super().__init__(address, CatalogHandler)
        self.new_api = new_api
        self.cpr = cpr
        self.cpr_authorization = f"Bearer {cpr_key}"

    def catalog(self, authorization):
        available = fetch("new_api", self.new_api, "/v1/models", authorization)
        if not isinstance(available, dict) or available.get("object") != "list" or (
            "success" in available and available["success"] is not True
        ):
            raise CatalogError(502, "new_api_invalid_response")
        ids = indexed_rows(available, "data", "id", "new_api")

        native = fetch("cpr", self.cpr, "/v1/models?client_version=0.169.0", self.cpr_authorization)
        models = indexed_rows(native, "models", "slug", "cpr")
        for model in models.values():
            if any(type(model.get(field)) is not kind for field, kind in MODEL_FIELDS.items()):
                raise CatalogError(502, "cpr_invalid_response")

        missing = sorted(ids.keys() - models.keys())
        if missing:
            token = authorization.split()[-1]
            cpr_key = self.cpr_authorization.split()[-1]
            names = [key for key in missing if token not in key and cpr_key not in key]
            logging.warning("CPR metadata missing for %d New API models: %s", len(missing), ascii(names))
        return {"models": [model for slug, model in models.items() if slug in ids]}

    def handle_error(self, request, client_address):
        logging.error("catalog connection failed")


class CatalogHandler(BaseHTTPRequestHandler):
    def setup(self):
        self.request.settimeout(10)
        super().setup()

    def log_message(self, *args):
        # The default logger includes the raw request target.
        pass

    def reply(self, status, body):
        self.send_response(status)
        self.send_header("Content-Type", "application/json")
        self.send_header("Cache-Control", "private, no-store")
        self.send_header("Content-Length", str(len(body)))
        self.end_headers()
        if self.command != "HEAD":
            self.wfile.write(body)

    def send_error(self, code, message=None, explain=None):
        self.reply(code, b'{"error":{"code":"http_error"}}')

    def do_GET(self):
        try:
            if self.path.partition("?")[0] != "/codex/models":
                raise CatalogError(404, "not_found")
            credentials = self.headers.get_all("Authorization", [])
            if len(credentials) != 1 or not BEARER.fullmatch(credentials[0]):
                raise CatalogError(401, "bearer_required")
            catalog = self.server.catalog(credentials[0])
            try:
                body = json.dumps(catalog, allow_nan=False).encode()
            except (ValueError, RecursionError):
                raise CatalogError(502, "cpr_invalid_response") from None
        except CatalogError as error:
            if error.status >= 500:
                logging.warning("%s", error.code)
            self.reply(error.status, json.dumps({"error": {"code": error.code}}).encode())
            return
        self.reply(200, body)


if __name__ == "__main__":
    cpr_key = os.environ.get("CPR_CLIENT_KEY", "")
    if not BEARER.fullmatch(f"Bearer {cpr_key}"):
        raise SystemExit("Configure CPR_CLIENT_KEY before starting")
    with CatalogServer(
        ("0.0.0.0", 8099),
        origin("NEW_API_ORIGIN", "http://new-api:3000"),
        origin("CPR_ORIGIN", "http://codex-proxy-rs:8080"),
        cpr_key,
    ) as server:
        server.serve_forever()
