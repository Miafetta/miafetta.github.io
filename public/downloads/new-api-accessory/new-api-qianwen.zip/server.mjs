import { timingSafeEqual } from 'node:crypto';
import { createServer } from 'node:http';
import { queryBoth } from './aliyun-bss.mjs';

const key = process.env.QIANWEN_API_KEY;
const ram = {
  accessKeyId: process.env.ALIBABA_CLOUD_ACCESS_KEY_ID,
  accessKeySecret: process.env.ALIBABA_CLOUD_ACCESS_KEY_SECRET,
  securityToken: process.env.ALIBABA_CLOUD_SECURITY_TOKEN,
  fundAccountId: process.env.ALIYUN_BSS_FUND_ACCOUNT_ID,
  timeoutMs: 9000,
  ...(process.env.NODE_ENV === 'test' && process.env.TEST_BSS_ORIGIN
    ? { endpoint: process.env.TEST_BSS_ORIGIN }
    : {}),
};
if (!key || !ram.accessKeyId || !ram.accessKeySecret) {
  throw new Error('Set QIANWEN_API_KEY and both Alibaba Cloud RAM credentials');
}
const expected = Buffer.from('Bearer ' + key);
let snapshot;
let pending;

async function getBalance() {
  if (snapshot && Date.now() - snapshot.checkedAt < 60000) return snapshot;
  // Publish both amounts only after both BSS queries succeed.
  pending ??= queryBoth(ram).then(({ fund, coupon }) => {
    snapshot = { fundCny: fund.amount, couponCny: coupon.amount, checkedAt: Date.now() };
    return snapshot;
  }).finally(() => { pending = undefined; });
  return pending;
}

function send(response, status, body) {
  response.writeHead(status, {
    'Content-Type': 'application/json; charset=utf-8',
    'Cache-Control': 'private, no-store',
  });
  response.end(JSON.stringify(body));
}

createServer(async (request, response) => {
  if (request.method === 'GET' && request.url === '/health') return send(response, 200, { ok: true });
  if (request.method !== 'GET' || request.url !== '/balance') {
    return send(response, 404, { error: 'Not found' });
  }
  const actual = Buffer.from(request.headers.authorization ?? '');
  if (actual.length !== expected.length || !timingSafeEqual(actual, expected)) {
    return send(response, 401, { error: 'Unauthorized' });
  }
  try {
    return send(response, 200, await getBalance());
  } catch (error) {
    const code = /^BSS_[A-Z0-9_]{1,48}$/.test(error?.message) ? error.message : 'BSS_UNAVAILABLE';
    console.error(code);
    return send(response, 503, { error: code });
  }
}).listen(8787, process.env.NODE_ENV === 'test' ? '127.0.0.1' : '0.0.0.0');
