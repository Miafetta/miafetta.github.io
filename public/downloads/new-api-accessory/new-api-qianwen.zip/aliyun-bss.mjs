// Read-only Alibaba Cloud BssOpenAPI 2023-09-30 client using ACS3-HMAC-SHA256.
// No third-party dependencies, no user-supplied outbound host in production.
import { createHash, createHmac, randomUUID } from 'node:crypto';

const DEFAULT_ENDPOINT = 'https://business.aliyuncs.com';
const hash = (s) => createHash('sha256').update(s).digest('hex');
const acceptable = (s) => typeof s === 'string' && /^[\w.\-]{3,200}$/.test(s);
function escapeRfc3986(s) {
  return encodeURIComponent(s).replace(/[!'()*]/g, c => '%' + c.charCodeAt(0).toString(16).toUpperCase());
}
export function makeRequest({ action, params = {}, accessKeyId, accessKeySecret, securityToken = '', now = new Date(), nonce = randomUUID(), endpoint = DEFAULT_ENDPOINT }) {
  if (!['DescribeCoupon', 'GetFundAccountAvailableAmount'].includes(action)) throw Error('BSS_INVALID_ACTION');
  if (!acceptable(accessKeyId) || !accessKeySecret) throw Error('BSS_CREDENTIALS_INVALID');
  const base = new URL(endpoint);
  if (base.protocol !== 'https:' && !(process.env.NODE_ENV === 'test' && base.hostname === '127.0.0.1')) throw Error('BSS_ENDPOINT_INVALID');
  if (process.env.NODE_ENV !== 'test' && base.origin !== DEFAULT_ENDPOINT) throw Error('BSS_ENDPOINT_INVALID');
  const q = Object.entries(params).filter(([,v]) => v !== undefined && v !== null && v !== '');
  q.sort(([a],[b]) => a < b ? -1 : a > b ? 1 : 0);
  const query = q.map(([k,v]) => `${escapeRfc3986(k)}=${escapeRfc3986(String(v))}`).join('&');
  const headers = {
    host: base.host,
    'x-acs-action': action,
    'x-acs-version': '2023-09-30',
    'x-acs-content-sha256': hash(''),
    'x-acs-date': now.toISOString().replace(/\.\d{3}Z$/, 'Z'),
    'x-acs-signature-nonce': nonce,
  };
  if (securityToken) headers['x-acs-security-token'] = securityToken;
  const signed = Object.keys(headers).sort();
  const canonicalHeaders = signed.map(k=>`${k}:${headers[k].trim()}\n`).join('');
  const canonical = ['POST', '/', query, canonicalHeaders, signed.join(';'), hash('')].join('\n');
  const signature = createHmac('sha256', accessKeySecret).update(`ACS3-HMAC-SHA256\n${hash(canonical)}`).digest('hex');
  headers.authorization = `ACS3-HMAC-SHA256 Credential=${accessKeyId},SignedHeaders=${signed.join(';')},Signature=${signature}`;
  return { url: `${base.origin}/` + (query ? `?${query}` : ''), headers, method: 'POST' };
}

export async function bssCall(cfg, action, params = {}) {
  const spec = makeRequest({ ...cfg, action, params });
  let response;
  try {
    response = await fetch(spec.url, {
      method: spec.method, headers: spec.headers, redirect: 'error', signal: AbortSignal.timeout(cfg.timeoutMs || 9000),
    });
  } catch (e) {
    throw Error(e?.name === 'TimeoutError' || e?.name === 'AbortError' ? 'BSS_TIMEOUT' : 'BSS_NETWORK_ERROR');
  }
  if (!response.ok) throw Error(`BSS_HTTP_${response.status}`);
  let raw;
  try { raw = await response.json(); } catch { throw Error('BSS_INVALID_JSON'); }
  if (!raw || typeof raw !== 'object' || raw.Code || raw.code) throw Error('BSS_API_ERROR');
  return raw.body && typeof raw.body === 'object' ? raw.body : raw;
}

export function readAmount(v, {allowNegative = false} = {}) {
  if (typeof v !== 'number' && typeof v !== 'string') throw Error('BSS_INVALID_AMOUNT');
  const s = String(v).trim();
  // BSS amounts are decimal strings; neither six decimal places nor plain
  // notation is guaranteed (for example, BigDecimal may emit "0E-8").
  const m = /^(-?)(\d+)(?:\.(\d+))?(?:[eE]([+-]?\d+))?$/.exec(s);
  if (!m || (!allowNegative && m[1]) || s.length > 128 || !Number.isFinite(Number(s))) throw Error('BSS_INVALID_AMOUNT');
  if (m[4] === undefined) return s;
  const exponent = Number(m[4]);
  if (!Number.isSafeInteger(exponent) || Math.abs(exponent) > 128) throw Error('BSS_INVALID_AMOUNT');
  const digits = m[2] + (m[3] || '');
  const point = m[2].length + exponent;
  const decimal = point <= 0 ? `0.${'0'.repeat(-point)}${digits}`
    : point >= digits.length ? digits + '0'.repeat(point - digits.length)
      : `${digits.slice(0, point)}.${digits.slice(point)}`;
  if (decimal.length > 128) throw Error('BSS_INVALID_AMOUNT');
  return m[1] + decimal;
}
function decimalUnits(value) {
  const [whole, fraction = ''] = readAmount(value).split('.');
  return { units: BigInt(whole + fraction), places: fraction.length };
}
function formatUnits(units, places) {
  if (places === 0) return String(units);
  const s = String(units).padStart(places + 1, '0');
  const frac = s.slice(-places).replace(/0+$/, '');
  return frac ? `${s.slice(0, -places)}.${frac}` : s.slice(0, -places);
}
function usableCoupon(c, now) {
  const state = String(c.Status || '').toUpperCase();
  if (state !== 'AVAILABLE') return false;
  if (c.StartTime) { const t = Date.parse(c.StartTime); if (!Number.isFinite(t)) throw Error('BSS_INVALID_COUPON_DATE'); if (t > now) return false; }
  if (c.EndTime) { const t = Date.parse(c.EndTime); if (!Number.isFinite(t)) throw Error('BSS_INVALID_COUPON_DATE'); if (t <= now) return false; }
  if ((c.Currency || 'CNY').toUpperCase() !== 'CNY') throw Error('BSS_COUPON_CURRENCY_UNSUPPORTED');
  return true;
}
export function summarizeCoupons(items, now = Date.now()) {
  if (!Array.isArray(items)) throw Error('BSS_INVALID_COUPON_RESPONSE');
  let amount = 0n;
  let places = 0;
  let count = 0;
  let nearestExpiry = null;
  const seen = new Set();
  for (const coupon of items) {
    if (!coupon || typeof coupon !== 'object') throw Error('BSS_INVALID_COUPON_RESPONSE');
    const id = coupon.CouponId ?? coupon.CouponNo;
    if (id != null) { if (seen.has(String(id))) continue; seen.add(String(id)); }
    if (!usableCoupon(coupon, now)) continue;
    // Percent-off-only vouchers have no monetary RemainAmount and are skipped.
    if (coupon.RemainAmount === undefined || coupon.RemainAmount === null || coupon.RemainAmount === '') continue;
    let n;
    try { n = decimalUnits(coupon.RemainAmount); }
    catch (e) {
      if (e?.message === 'BSS_INVALID_AMOUNT') throw Error('BSS_INVALID_COUPON_AMOUNT');
      throw e;
    }
    if (n.units === 0n) continue;
    // Align decimal scales exactly, without floating-point rounding.
    if (n.places > places) {
      amount *= 10n ** BigInt(n.places - places);
      places = n.places;
    }
    amount += n.units * 10n ** BigInt(places - n.places);
    count++;
    if (coupon.EndTime) {
      const ts = Date.parse(coupon.EndTime);
      if (nearestExpiry === null || ts < nearestExpiry) nearestExpiry = ts;
    }
  }
  return { amount: formatUnits(amount, places), count, nearestExpiry: nearestExpiry ? new Date(nearestExpiry).toISOString() : null };
}
export async function getFundBalance(cfg) {
  const params = cfg.fundAccountId ? { FundAccountId: cfg.fundAccountId } : {};
  const data = await bssCall(cfg, 'GetFundAccountAvailableAmount', params);
  const currency = String(data.Currency || 'CNY').toUpperCase();
  if (currency !== 'CNY') throw Error('BSS_FUND_CURRENCY_UNSUPPORTED');
  return { amount: readAmount(data.AvailableAmount,{allowNegative:true}), currency, fundAccountId: String(data.FundAccountId || '') };
}
export async function getCouponBalance(cfg) {
  const all = [];
  const seen = new Set();
  const pageSize = 100;
  for (let page = 1; page <= 30; page++) {
    const data = await bssCall(cfg, 'DescribeCoupon', { CurrentPage: page, PageSize: pageSize, Status: 'AVAILABLE' });
    const count = data.TotalCount;
    if (!Array.isArray(data.Data) || !Number.isSafeInteger(count) || count < 0) throw Error('BSS_INVALID_COUPON_RESPONSE');
    for (const coupon of data.Data) {
      const id = coupon?.CouponId ?? coupon?.CouponNo;
      if (id == null) continue;
      if (seen.has(String(id))) throw Error('BSS_COUPON_PAGINATION_STALLED');
      seen.add(String(id));
    }
    all.push(...data.Data);
    if (all.length >= count) return summarizeCoupons(all);
    if (data.Data.length === 0) throw Error('BSS_COUPON_PAGINATION_STALLED');
  }
  throw Error('BSS_COUPON_PAGE_LIMIT'); // never silently report an incomplete sum
}
export async function queryBoth(cfg) {
  // Cash+coupon snapshot is updated atomically: avoid mixing readings from unrelated refresh cycles.
  const [fund, coupon] = await Promise.all([getFundBalance(cfg), getCouponBalance(cfg)]);
  return { fund, coupon };
}
